Get started quickly using one of the video tutorials or simply follow the instructions below

Make sure to add your bnet account login in the format email|pass in account.ini file in the bot folder.

1- Place Settings.json file in the saved games\diablo 2 resurrected folder
2- Edit your class config file accordingly with notepad or using jieguan config editor. Make sure you set pickit .nip file named correctly.
3- Put the bot folder in the C:\ same as where your d2r install is in the c drive filepath which must contain only english letters.
4- Dont name your folder or exe jieguan of course this is obvious but nobody listens so ill set the default name for you as something random.
5- You will have a temp folder created that can be deleted if you encounter any errors that are not:
 -failed to verify (hwid needs to be reset by opening helpdesk ticket or pm-ing admin on forum) or 
-license expired (key needs to be renewed or changed with new key by deleting loader.dat where key is saved)
6- loader.dat is where your key is saved , this file will be created after the first launch. Delete it to enter a new key whenver you change your key or enter it incorrectly.
- loader.bin is the brain of the bot, you will not want to combine the mh folder with the bot folder, keep zhipei and jieguan folders separate if you plan to have both.
7- If you are seting up your character settings in game will need to be also updated for the bot to use the numpad 9 key as the toggle legacy graphics G hotkey
-Go to controls tab in game settings -> go to legacy graphics hotkey and update it from G to numpad 9 (Use on screen keyboard if you do not have numpad 9 on your keyboard)
8. Always double check your class config settings, also make sure to post in the forum and introduce yourself at https://www.afkbots.com/categories/jieguan-take-over-bot.8/
9. Use the jieguan config editor to have an easier time with setting up but you don't need to use it, the scheduler however will be 1 of the more important tools
-Set your jieguan scheduler to take a break between 5AM-11AM MST (More info about avoiding bans with tips like this in the forum)

For more credits use the get credits page https://revamped.app/shop/signup

Please join our forum to see JieGuan setup tutorials, guides and ask support questions. It has been remade again on new platform to integrate all our resellers into the forum,
https://www.afkbots.com/app/signup



If you need key for jieguan config editor just get a free 6 day key or get the aio launcher to get access to many bots.


Made with lots of passion, always do your best!


Join the revamped escrow marketplace https://revamped.app/shop/marketplace

Check out our crypto trading bot, it's free to try: https://bitbot.ninja