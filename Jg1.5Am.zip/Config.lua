--[[ 
			#### Class Setup ####

	Put what is your folder and character lua
	Example: Config.Class = "builds\\blizz"
	
	this mean you are have folder call "builds" and inside
	you are have file call blizz.lua
	
]]--
Config.Class = "Classes\\PaladinFull"